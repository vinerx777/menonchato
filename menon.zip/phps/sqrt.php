<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nome</title>
    <link rel="stylesheet" href="../style.css">
    <style>
        /*
         colocar estilos de cada página aqui para ficar feio nelas 
        */
    </style>
</head>
<body>
    <main>
        <!--Forms padrão p/cada página-->
        <h1>SQRT</h1>

        
        <!-- Texto adicionado -->
        <p>Em matemática, "sqrt" é uma abreviação comum para "raiz quadrada". A raiz quadrada de um número é um valor que, quando multiplicado por si mesmo, resulta no número original. Por exemplo, a raiz quadrada de 9 é 3, pois 3 vezes 3 é igual a 9.</p>
        <p>A notação matemática para a raiz quadrada de um número <span>&radic;x</span> é &radic;<span>x</span>. Por exemplo:</p>
        <ul>
            <li>&radic;4 é igual a 2, pois 2 &times; 2 = 4.</li>
            <li>&radic;25 é igual a 5, pois 5 &times; 5 = 25.</li>
            <li>&radic;100 é igual a 10, pois 10 &times; 10 = 100.</li>
        </ul>
        <p>A raiz quadrada pode ser um número positivo ou negativo, mas quando se usa a notação &radic;x, geralmente se refere à raiz quadrada positiva.</p>

        <form action="sqrt.php" method="get">
            <label for="inum">Digite um número:</label>
            <input type="number" name="inum5" id="inum5">

            <button type="submit">Enviar</button>
        </form>
        <?php 
          if(isset($_GET['inum5'])) {
            $inum5 = $_GET['inum5'];

            $resultado = sqrt($inum);
            echo "<p>O valor de SQRT é $resultado</p>";
          }
        ?>
        
        <p><a href="../funçao.htm">Volte à página principal</a></p>
    </main>
</body>
</html>
