<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nome</title>
    <link rel="stylesheet" href="../style.css">
    <style>
        /*
         colocar estilos de cada página aqui para ficar feio nelas 
        */
    </style>
</head>
<body>
    <main>
        <!--Forms padrão p/cada página-->
        <h1>Min</h1>

        <p>
            A função "min" é utilizada para encontrar o menor valor em um conjunto de valores ou argumentos.
        </p>
        <p>
            A sintaxe da função "min" é a seguinte:
        </p>
        <pre><code>min(valor1, valor2, ..., valorN)</code></pre>
        <p>
            A função "min" retorna o menor valor entre os valores passados como argumentos.
        </p>
        <p>
            <code>min(10, 5, 8)</code> retorna 5, pois é o menor valor entre os números 10, 5 e 8.
        </p>
        <p>
            <code>min(100, 200, 150, 50)</code> retorna 50, pois é o menor valor entre os números 100, 200, 150 e 50.
        </p>
        <p>
            <code>min(1, 2, 3, 4, 5)</code> retorna 1, pois é o menor valor entre os números 1, 2, 3, 4 e 5.
        </p>

        <p>
            <label for="inum">Digite um número:</label>
            <input type="number" name="inum" id="inum">
        </p>

        <p><a href="../funçao.htm">Volte à página principal</a></p>
    </main>
</body>
</html>