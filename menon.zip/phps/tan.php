<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nome</title>
    <link rel="stylesheet" href="../style.css">
    <style>
        /*
         colocar estilos de cada página aqui para ficar feio nelas 
        */
    </style>
</head>
<body>
    <main>
        <!--Forms padrão p/cada página-->
        <h1>Tangente</h1>
        <p>
            Em trigonometria, a tangente de um ângulo em um triângulo retângulo é uma razão entre o comprimento do lado oposto ao ângulo e o comprimento do lado adjacente a esse ângulo.
        </p>
        <p>
            Matematicamente, a tangente de um ângulo θ é definida como:
            <br>
            <strong>tan(θ) = lado_oposto / lado_adjacente</strong>
        </p>
        <p>
            Para calcular a tangente de um ângulo, você divide o comprimento do lado oposto pelo comprimento do lado adjacente ao ângulo.
        </p>
        <p>
            Por exemplo, se tivermos um triângulo retângulo com um ângulo de 30 graus e o comprimento do lado oposto a esse ângulo é 3 e o comprimento do lado adjacente é 2, então:
            <br>
            <strong>tan(30°) = 3 / 2 = 1.5</strong>
        </p>

       <form action="tan.php" method="get">
           <label for="inum">Digite um número:</label>
           <input type="number" name="inum3" id="inum3">

           <button type="submit">Enviar</button>
       </form>
       <?php 
         if(isset($_GET['inum3'])) {
           $inum3 = $_GET['inum3'];

           $resultado = tan($inum);
           echo "<p>O valor tangente  é $resultado</p>";
         }
       ?>


        <p><a href="../funçao.htm">Volte à página principal</a></p>
    </main>
</body>
</html>