<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nome</title>
    <link rel="stylesheet" href="../style.css">
    <style>
        /*
         colocar estilos de cada página aqui para ficar feio nelas 
        */
    </style>
</head>
<body>
    <main>
        <!--Forms padrão p/cada página-->
        <h1>π </h1>

        <p>
            A constante π (pi) é um número irracional que representa a relação entre a circunferência de um círculo e o seu diâmetro. O valor de π é aproximadamente 3.14159.
        </p>
        <p>
            A constante π é amplamente utilizada em matemática, física, engenharia e muitas outras áreas.
        </p>
        <p>
            O valor de π é utilizado em uma variedade de fórmulas e equações em diversas áreas da ciência e da matemática.
        </p>
        <p>
            <label for="inum">Digite um número:</label>
            <input type="number" name="inum" id="inum">
        </p>

        <p><a href="../funçao.htm">Volte à página principal</a></p>
    </main>
</body>
</html>