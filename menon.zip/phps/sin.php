<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nome</title>
    <link rel="stylesheet" href="../style.css">
    <style>
        /*
         colocar estilos de cada página aqui para ficar feio nelas 
        */
    </style>
</head>
<body>
    <main>
        <!--Forms padrão p/cada página-->
        <h1>Seno</h1>

        <p>
            Em trigonometria, o seno de um ângulo em um triângulo retângulo é uma razão entre o comprimento do lado oposto ao ângulo e a hipotenusa do triângulo.
        </p>
        <p>
            Matematicamente, o seno de um ângulo θ é definido como:
            <br>
            <strong>sin(θ) = lado_oposto / hipotenusa</strong>
        </p>
        <p>
            O seno é uma das funções trigonométricas fundamentais e é amplamente utilizado em diversas áreas, como física, engenharia e matemática aplicada.
        </p>

       <form action="sin.php" method="get">
           <label for="inum6">Digite um número:</label>
           <input type="number" name="inum6" id="inum6">

           <button type="submit">Enviar</button>
       </form>
       <?php 
         if(isset($_GET['inum6'])) {
           $inum6 = $_GET['inum6'];

           $resultado = sin($inum);
           echo "<p>O valor sin é $resultado</p>";
         }
       ?>

        <p><a href="../funçao.htm">Volte à página principal</a></p>
    </main>
</body>
</html>