<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nome</title>
    <link rel="stylesheet" href="../style.css">
    <style>
        /*
         colocar estilos de cada página aqui para ficar feio nelas 
        */
    </style>
</head>
<body>
    <main>
        <!--Forms padrão p/cada página-->
        <h1>Base</h1>

        <p>
            A função "base_convert" é utilizada para converter um número de uma base para outra.
        </p>
        <p>
            A sintaxe da função "base_convert" é a seguinte:
        </p>
        <pre><code>base_convert(numero, base_origem, base_destino)</code></pre>
        <p>
            A função "base_convert" retorna a representação de <code>numero</code> na base especificada por <code>base_destino</code>.
        </p>
        <h2>Exemplo:</h2>
        <p>
            Se quisermos converter o número decimal 10 para binário, podemos usar <code>base_convert(10, 10, 2)</code>, o que resultará em "1010".
        </p>
        <p>
            Da mesma forma, para converter o número binário "1010" para decimal, podemos usar <code>base_convert("1010", 2, 10)</code>, o que resultará em 10.
        </p>

        <p>
            <label for="inum">Digite um número:</label>
            <input type="number" name="inum" id="inum">
        </p>

        <p><a href="../funçao.htm">Volte à página principal</a></p>
    </main>
</body>
</html>