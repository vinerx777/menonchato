<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nome</title>
    <link rel="stylesheet" href="../style.css">
</head>
<body>
    <main>
        <h1>Cosseno</h1>

        <p>
            Em trigonometria, o cosseno de um ângulo em um triângulo retângulo é uma razão entre o comprimento do lado adjacente ao ângulo e a hipotenusa do triângulo.
        </p>
        <p>
            Matematicamente, o cosseno de um ângulo θ é definido como:
            <br>
            <strong>cos(θ) = lado_adjacente / hipotenusa</strong>
        </p>
        <p>
            O cosseno é uma das funções trigonométricas fundamentais e é amplamente utilizado em diversas áreas, como física, engenharia e matemática aplicada.
        </p>

      <form action="cos.php" method="get">
          <label for="inum">Digite um número:</label>
          <input type="number" name="inum2" id="inum2">

          <button type="submit">Enviar</button>
      </form>
      <?php 
        if(isset($_GET['inum2'])) {
          $inum2 = $_GET['inum2'];

          $resultado = cos($inum);
          echo "<p>O valor de cos  é $resultado</p>";
        }
      ?>

        <p><a href="funçao.html">Volte à página principal</a></p>
    </main>
</body>
</html>