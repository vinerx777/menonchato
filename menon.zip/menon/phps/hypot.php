<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nome</title>
    <link rel="stylesheet" href="../style.css">
</head>
<body>
    <main>
        <h1>hipotenusa</h1>

        <p>
            A função "hypot" é utilizada para calcular a hipotenusa de um triângulo retângulo dado os comprimentos de seus catetos.
        </p>
        <p>
            A sintaxe da função "hypot" é a seguinte:
        </p>
        <pre><code>hypot(cateto1, cateto2)</code></pre>
        <p>
            A função "hypot" retorna o comprimento da hipotenusa de um triângulo retângulo, calculado usando o teorema de Pitágoras.
        </p>
        <h2>Exemplo:</h2>
        <p>
            Se tivermos um triângulo retângulo com cateto1 = 3 e cateto2 = 4, então <code>hypot(3, 4)</code> retornará 5, pois a hipotenusa é calculada como √(3^2 + 4^2) = √(9 + 16) = √25 = 5.
        </p>

        <form action="hypot.php" method="get">
          <label for="inum57">Digite um número:</label>
          <input type="number" name="inum57" id="inum57">
          <label for="inum8">Digite 2 número:</label>
          <input type="number" name="inum58" id="inum58">

          <button type="submit">Enviar</button>
      </form>
      <?php 
        if(isset($_GET['inum57']) && isset($_GET['inum58'])) {
          $inum7 = $_GET['inum57'];
          $inum8 = $_GET['inum58'];

          $resultado = hypot($inum57, $inum58);
          echo "<p>O resultado é $resultado</p>";
        }
      ?>
        <p><a href="funçao.html">Volte à página principal</a></p>
    </main>
</body>
</html>