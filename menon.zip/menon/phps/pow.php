<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nome</title>
    <link rel="stylesheet" href="../style.css">
</head>
<body>
    <main>
        <h1>potência</h1>
 
        <p>
            A função "pow" em matemática é utilizada para calcular uma base elevada a uma potência. Matematicamente, a função "pow" é representada como:
        </p>
        <p>
            <strong>pow(base, expoente)</strong>
        </p>
        <p>
            Isso retorna o valor da base elevada ao expoente.
        </p>
        <p>
            <strong>pow(2, 3)</strong> resulta em 8, pois 2 elevado a 3 é igual a 8.
        </p>
        <p>
            <strong>pow(5, 2)</strong> resulta em 25, pois 5 elevado ao quadrado é igual a 25.
        </p>
        <p>
            <strong>pow(10, 0)</strong> resulta em 1, pois qualquer número elevado a 0 é igual a 1.
        </p>
        
      <form action="pow.php" method="get">
          <label for="inum7">Digite um número:</label>
          <input type="number" name="inum7" id="inum7">
          <label for="inum8">Digite 2 número:</label>
          <input type="number" name="inum8" id="inum8">

          <button type="submit">Enviar</button>
      </form>
      <?php 
        if(isset($_GET['inum7']) && isset($_GET['inum8'])) {
          $inum7 = $_GET['inum7'];
          $inum8 = $_GET['inum8'];

          $resultado = pow($inum7, $inum8);
          echo "<p>O resultado é $resultado</p>";
        }
      ?>

        <p><a href="funçao.html">Volte à página principal</a></p>
    </main>
</body>
</html>