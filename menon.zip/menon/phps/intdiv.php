<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nome</title>
    <link rel="stylesheet" href="../style.css">
</head>
<body>
    <main>
        <h1>intdiv</h1>

        <p>
            A função "intdiv" é utilizada para dividir dois números e retornar o resultado como um número inteiro.
        </p>
        <p>
            A sintaxe da função "intdiv" é a seguinte:
        </p>
        <pre><code>intdiv(dividendo, divisor)</code></pre>
        <p>
            A função "intdiv" retorna o resultado da divisão do dividendo pelo divisor, com o resultado arredondado para o número inteiro mais próximo em direção a zero.
        </p>
        <p>
            <code>intdiv(10, 3)</code> retorna 3, pois a divisão de 10 por 3 resulta em 3.333..., que é arredondado para o número inteiro mais próximo em direção a zero.
        </p>
        <p>
            <code>intdiv(20, 7)</code> retorna 2, pois a divisão de 20 por 7 resulta em aproximadamente 2.857..., que é arredondado para o número inteiro mais próximo em direção a zero.
        </p>

       <form action="intdiv.php" method="get">
           <label for="inum21">Digite um número:</label>
           <input type="number" name="inum21" id="inum21">

           <label for="inum22">Digite o 2 número:</label>
           <input type="number" name="inum22" id="inum22">

           <button type="submit">Enviar</button>
       </form>
       <?php 

    if(isset($_GET['inum21']) && isset($_GET['inum22'])) {
    $inum7 = $_GET['inum12'];
    $inum8 = $_GET['inum13'];

    $resultado = intdiv($inum21, $inum22);
    echo "<p>O resultado é $resultado</p>";
}
       ?>

        <p><a href="../funçao.htm">Volte à página principal</a></p>
    </main>
</body>
</html>