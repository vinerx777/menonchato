<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nome</title>
    <link rel="stylesheet" href="../style.css">
</head>
<body>
    <main>
        <h1>Abisoluto</h1>

        <p>
            A função "abs" é utilizada para retornar o valor absoluto de um número.
        </p>
        <p>
            A sintaxe da função "abs" é a seguinte:
        </p>
        <pre><code>abs(numero)</code></pre>
        <p>
            A função "abs" retorna o valor absoluto do número fornecido como argumento. O valor absoluto de um número é sua distância em relação a zero na reta numérica, ignorando seu sinal.
        </p>
        <p>
            Se tivermos o número -10, seu valor absoluto seria 10. Portanto, <code>abs(-10)</code> retornaria 10.
        </p>
        <p>
            Da mesma forma, para o número 5, seu valor absoluto é 5, então <code>abs(5)</code> também retornaria 5.
            
        <form action="abs.php" method="get">
            <label for="inum">Digite um número:</label>
            <input type="number" name="inum" id="inum">

            <button type="submit">Enviar</button>
        </form>
        <?php 
          if(isset($_GET['inum'])) {
            $inum = $_GET['inum'];

            $resultado = abs($inum);
            echo "<p>O valor absoluto  é $resultado</p>";
          }
        ?>

        <p><a href="../funçao.html">Volte à página principal</a></p>
    </main>
</body>
</html>