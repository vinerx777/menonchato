<!DOCTYPE html>
<html lang="pr-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Funções Matematicas</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <h1>Contas</h1>
    <main>
        <p class="tit"><strong>Veja o que cada um  faz:</strong></p>
        <p><a href="phps/abs.php">abs</a></p>
        <p><a href="phps/base_convert.php">Base_convert</a></p>
        <p><a href="phps/hypot.php">hypot</a></p>
        <p><a href="phps/intdiv.php">intdiv</a></p>
        <p><a href="phps/min.php">min</a></p>
        <p><a href="phps/max.php">max</a></p>
        <p><a href="phps/pi.php">pi</a></p>
        <p><a href="phps/pow.php">pow</a></p>
        <p><a href="phps/sin.php">sin</a></p>
        <p><a href="phps/cos.php">cos</a></p>
        <p><a href="phps/tan.php">tan</a></p>
        <p><a href="phps/sqrt.php">sqrt</a></p>

    </main>

</body>
</html>