<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <title>cor</title>
</head>
<body>
  <form action="<?php echo $_SERVER["PHP_SELF"]?>" method="get">
    <label for="valor">Escolha um valor Inicial:</label>
      <input type="text" name="inicio"> 
        <br></br>
    <label for="valor">Escolha um valor Final:</label>
    <input type="text" name="fim"> 
    <input type="submit">
  </form>

<?php
  $inicio = $_GET["inicio"];
  $fim = $_GET["fim"];
  for ($inicio; $inicio != $fim ; $inicio++){
    echo "$inicio <br>";
}
  ?>


</body>
</html>