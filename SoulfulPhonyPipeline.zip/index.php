<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <title>cor</title>
</head>
<body>
  <form method="get">"
    <label for="cor">Escolha uma cor:</label>
      <input type="text" id="cor" name="cor">
    <input type="submit" value="Verificar">
  </form>
  
<?php
  
  $cores = $_GET ['cor'];
  
  if ($cores == "azul" || $cores == "AZUL"){
      echo "o preço do jogo é R$50,00";
  } elseif ($cores == "amarelo") {
      echo "o preço do jogo é R$100,00";
  } elseif ($cores == "branco") {
      echo "o preço do jogo é R$150,00";
  } else {
      echo "cor inválida.";
  }
  
  ?>


</body>
</html>
